"""CLI interface for reddress."""

import click
from .core import greet_user, process_data

@click.group()
@click.version_option()
def main():
    """Reddress CLI - Your package description."""
    pass

@main.command()
def start():
    """Check installation and display welcome message."""
    message = greet_user()
    click.echo(click.style(message, fg='green', bold=True))

@main.command()
def help():
    message = "hay baby"
    click.echo(click.style(message, fg='green', bold=True))



if __name__ == "__main__":
    main()
