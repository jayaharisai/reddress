def greet_user():
    """Display welcome message after installation."""
    return "Installed successfully! Let's get started"

def process_data(data):
    """Example function to process data."""
    # Add your actual functionality here
    return f"Processing: {data}"